![Logo](admin/viessmann.png)
# ioBroker.viessmann
=================

![Number of Installations](http://iobroker.live/badges/viessmann-installed.svg) ![Number of Installations](http://iobroker.live/badges/viessmann-stable.svg) [![NPM version](http://img.shields.io/npm/v/iobroker.viessmann.svg)](https://www.npmjs.com/package/iobroker.viessmann)
[![Downloads](https://img.shields.io/npm/dm/iobroker.viessmann.svg)](https://www.npmjs.com/package/iobroker.viessmann)

**Github Actions**:
![GitHub Actions](https://github.com/misanorot/ioBroker.viessmann/workflows/Test%20and%20Release/badge.svg)

[![NPM](https://nodei.co/npm/iobroker.viessmann.png?downloads=true)](https://nodei.co/npm/iobroker.viessmann/)

[![paypal](https://www.paypalobjects.com/en_US/DK/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZYHW84XXF5REJ&source=url)

## Viessmann über vcontrold

**[Deutsche Beschreibung](docs/de/viessmann.md)**

## Viessmann via vcontrold

**[English description](docs/en/viessmann_en.md)**

******************************************************************************************
*die benutzten Bilder stammen von www.viessmann.com.*

## ToDo
	- Anderung der Vito.xml ohne Verlust der Einstellungen
	- Implementierung Unit on/off

## Changelog
<!--
    Placeholder for the next version (at the beginning of the line):
    ### **WORK IN PROGRESS**
-->
### 1.7.4 (2026-03-15)
* (misanorot) update packages

### 1.7.3 (2025-10-26)
* (misanorot) update npm progress

### 1.7.2 (2025-10-12)
* (misanorot) update packages

### 1.7.1 (2025-06-01)
* (ghecker1) optimize reconnect

### 1.6.0 (2025-05-03)
* (misanorot) node 20 require

### License

The MIT License (MIT)

Copyright (c) 2017-2026 misanorot <audi16v@gmx.de>